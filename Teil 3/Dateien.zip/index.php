<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>LAP IT Bsp. 2</title>
<?php include("content/parts/head.part.html"); ?>
</head>

<body>
	<h1>Home</h1>
	<p>Bitte wählen Sie aus der untenstehenden Navigation aus:</p>
	<?php include("content/parts/navigation.part.html"); ?>
</body>
</html>