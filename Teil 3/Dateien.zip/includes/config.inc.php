<?php
define("TESTMODE",1);

define("DB",array(
	"host" => "localhost",
	"user" => "root",
	"pwd" => "",
	"name" => "db_lap2"
));
?>